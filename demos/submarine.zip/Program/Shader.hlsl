struct light
{
	bool enabled; //
	float4 position; // w=0 dir, (0,0,-1,0)
	float4 ambient; // (0,0,0,1)
	float4 diffuse; // 0:(1,1,1,1), (0,0,0,0)
	float4 specular; // 0:(1,1,1,1), (0,0,0,0)
	float spot_cutoff; // 180deg (dflt) xor [0,90]deg
	float3 spot_direction; // (0,0,1)
	float spot_exponent; // [0,128]
	float3 attenuation; // (c:1,l:0,q:0)
};

Texture2D colorMap:register(t0);
Texture2D specularMap:register(t1);
Texture2D normalMap:register(t2);
Texture2D shadowMap : register(t3); // depth texture.

SamplerState colorSampler:register(s0);
SamplerComparisonState comparisonSampler : register(s1); // shadow comparison sampler.

StructuredBuffer<light> light_list : register(t4);

float3 get_light_vector(light lgt, float3 pos) {
	return ((0.0 != lgt.position.w) ? (lgt.position.xyz - pos)
		: (lgt.position.xyz));
}

float get_light_attenuation(light lgt, float dist){
	float attenuation_at_lpos_infty = 1.0;
	return ((0.0 != lgt.position.w) ? 1.0 / ((lgt.attenuation.x) +
		(lgt.attenuation.y * dist) +
		(lgt.attenuation.z * dist * dist)) : attenuation_at_lpos_infty);
}

void accumulate_lights(StructuredBuffer<light> lgt, float3 pos, float3 norm, float3 eye, float shininess, inout float4 iambient, inout float4 idiffuse, inout float4 ispecular, int numL){
	uint lgt_size = 0, dummy = 0; lgt.GetDimensions(lgt_size, dummy);
	for (uint index = 0; index < numL; ++index) {

		if (lgt[index].enabled) {

			float3 lvec = get_light_vector(lgt[index], pos);
			float attenuation = get_light_attenuation(lgt[index], length(lvec));
			lvec = normalize(lvec);
			float NdotL = max(dot(norm, lvec), 0.0);

				if (0.0 < NdotL) {

				if (2 == lgt[index].position.w) {
					float cos_cur_angle = dot(-lvec, normalize(lgt[index].spot_direction));
					float cos_outer_angle = saturate(cos(lgt[index].spot_cutoff));
					float cos_inner_angle = saturate(cos((1.0 - (lgt[index].spot_exponent / 128.0)) * lgt[index].spot_cutoff));
					attenuation *= saturate((cos_cur_angle - cos_outer_angle) / (cos_inner_angle - cos_outer_angle));
				}

				float3 H = normalize(lvec - normalize(pos - eye));
					float NdotH = max(dot(norm, H), 0.0);
				float exponent = max(128.0 / max(0.0, min(128.0, shininess)), 0.0);
				float4 lit_result = lit(NdotL, NdotH, exponent);

			    iambient += (attenuation * lgt[index].ambient * lit_result.x);
				idiffuse += (attenuation * lgt[index].diffuse * lit_result.y);
				ispecular += (attenuation * lgt[index].specular * lit_result.z);
			}

		}
	}
}

float3 applyFog(in float3 rgb, in float distance){
	float fogAmount = 1.0 - exp(-distance);
	float3 fogColor = float3(0.0, 0.02, 0.05);
	return lerp(rgb, fogColor, fogAmount);
}

struct VIn {
	float4 position : POSITION;
	float3 nor : NORMAL;
	float3 tang : TANGENT;
	float2 uv : TEXCOORD;
};

struct VOut {
	float4 position : SV_POSITION;
	float4 posWorld : V_POSITION;
	float4 normal : NORMAL;
	float2 tex0 : TEXCOORD;
};

struct VOutDepth {
    float4 position : SV_POSITION;
};

cbuffer Uniforms_PerFrame {
	float4x4 MVP;
	float4x4 INV_TRANSP_WORLD;
	float4x4 WORLD;
	float4 renderMode;
	float4x4 lightViewMatrix;
	float4x4 lightProjectionMatrix;
	float4 Mat_Ambient;
	float4 Mat_Diffuse;
	float4 Mat_Specular;
	float time;
	float3 numLights;
	float3 camPos;
	float fogAmt;
}

VOutDepth DepthPassVS(VIn input) {
	VOutDepth output;
	output.position = mul(MVP, float4(input.position.xyz, 1.0f));
	return output;
}

void DepthPassPS(VOutDepth input) {

}

VOut VShader(VIn input) {
	VOut output;
	float4 vertex = input.position;
	output.position = mul(MVP, float4(vertex.xyz, 1));
	output.posWorld = mul(WORLD, float4(vertex.xyz, 1));
	output.normal = mul(INV_TRANSP_WORLD, normalize(float4(input.nor, 0)));
	output.tex0 = input.uv;
	return output;
}


VOut VShaderFish(VIn input) {
	VOut output;
	float4 vertex = input.position;

	if (vertex.x < 0){
		vertex.z += (sin(time * 6) * vertex.x);
	}
	output.position = mul(MVP, float4(vertex.xyz, 1));
	output.posWorld = mul(WORLD, float4(vertex.xyz, 1));
	output.normal = mul(INV_TRANSP_WORLD, normalize(float4(input.nor, 0)));
	output.tex0 = input.uv;
	return output;
}

VOut VShaderFishTail(VIn input) {
	VOut output;
	float4 vertex = input.position;
	vertex.z -= (sin(time * 6) * 1.8);
	output.position = mul(MVP, float4(vertex.xyz, 1));
	output.posWorld = mul(WORLD, float4(vertex.xyz, 1));
	output.normal = mul(INV_TRANSP_WORLD, normalize(float4(input.nor, 0)));
	output.tex0 = input.uv;
	return output;
}

float4 fp_main(float4 position : SV_POSITION, float4 posWorld : V_POSITION, float4 normal : NORMAL, float2 tex0 : TEXCOORD) : SV_TARGET{
	float4 result = float4(0, 0, 0, 0);
	float4 ambientL = float4(0, 0, 0, 0);
	float4 diffuseL = float4(0, 0, 0, 0);
	float4 specularL = float4(0, 0, 0, 0);

	accumulate_lights(light_list, posWorld.xyz, normalize(normal.xyz), camPos, 0.1, ambientL, diffuseL, specularL, 10);

	float4 diffTexel = colorMap.Sample(colorSampler, tex0);

	float4x4 offset_mat = float4x4(	0.5, 0.0, 0.0, 0.0,
									0.0, -0.5, 0.0, 0.0,
									0.0, 0.0, 1.0, 0.0,
									0.5, 0.5, 0.0, 1.0);

	float4 shadow_coords = posWorld;
	shadow_coords = mul(shadow_coords, transpose(lightViewMatrix));
	shadow_coords = mul(shadow_coords, transpose(lightProjectionMatrix));
	shadow_coords /= shadow_coords.w;
	shadow_coords = mul(shadow_coords, offset_mat);

	float shadow = 0.0f;

	float pxSize = 1.0 / 4096.0;
	const float2 offsets[9] = {
				float2(-pxSize, -pxSize),	float2(0.0, -pxSize),	float2(pxSize, -pxSize),
				float2(-pxSize, 0.0),		float2(0.0, 0.0),		float2(pxSize, 0.0),
				float2(-pxSize, +pxSize),	float2(0.0, +pxSize),	float2(pxSize, +pxSize)
	};

	[unroll]
	for (int i = 0; i < 9; ++i){
		shadow += shadowMap.SampleCmpLevelZero(comparisonSampler, shadow_coords.xy + offsets[i], shadow_coords.z).r;
	}

	shadow = saturate(shadow);

	float4 rgbColour = float4(0, 0, 0, 0);

	rgbColour += Mat_Ambient * diffTexel;
	rgbColour += diffuseL * Mat_Diffuse * diffTexel * shadow;
	rgbColour += specularL * Mat_Specular * shadow;

	float alpha = rgbColour.a;
	result = float4(applyFog(rgbColour.rgb, length(camPos - posWorld.xyz)* 0.015 * fogAmt), rgbColour.a);

	if (renderMode.x != 0.0) {
		//sepia
		result.r = (result.r * 0.393) + (result.g * 0.769) + (result.b * 0.189);
		result.g = (result.r * 0.349) + (result.g * 0.686) + (result.b * 0.168);
		result.b = (result.r * 0.272) + (result.g * 0.534) + (result.b * 0.131);
    }
	else if (renderMode.y != 0.0)
    {
		// B&W
		// 'Average' method
		//float colour = (result.r + result.g + result.b) / 3;
		//result = float4(colour, colour, colour, Mat_Diffuse.a);

		// 'Weighted' method (more priority to green as brightness for human eyes)
		float colour = (result.r * 0.3) + (result.g * 0.59) + (result.b * 0.11);
		result = float4(colour, colour, colour, Mat_Diffuse.a);
    }
	else if (renderMode.z != 0.0){
		// Toon
		result.r = result.r - (result.r % renderMode.a);
		result.g = result.g - (result.g % renderMode.a);
		result.b = result.b - (result.b % renderMode.a);
	}

	return result;

}

