Requires:

Oculus DK2 HMD and constellation sensor		(USB3)
Kinect V2 Sensor (with PC connection kit)	(USB3)
Leap Motion sensor							(USB3)

See http://chris-donnelly.github.com/vpaint.html for setup information and project details
