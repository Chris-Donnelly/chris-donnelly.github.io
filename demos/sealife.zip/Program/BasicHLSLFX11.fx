//DOC

//_____________________________________________________ Globals
#define EPSILON_NRM (0.1 / iResolution.x)

float       g_windowWidth;             // Window width
float       g_windowHeight;            // Window height
float       g_fTime;                   // App's time in seconds
float4x4    g_mWorld;                  // World matrix for object
float4x4    g_mWorldViewProjection;    // World * View * Projection matrix
float3      eyePosition = float3(0, 12, 50);
float       nearPlane = 1;
float       farPlane = 500;
float4      bgColour = float4(0.01, 0.4, 0.65, 1.0);

float       MAX_STEPS = 950; // lower values = higher distortion
float       MIN_DISTANCE = 0;
float       MAX_DISTANCE = 500;

float       ERR_TOLERANCE = 0.0001;
float3      lightPos = float3(0, 100, 100);
int         g_nNumLights;

float		SEAWEED_TWIST = 0.148;
float		SEAWEED_HEIGHT = 50;
float		SEAWEED_WIDTH = 0.6;
float		SEAWEED_TWISTRATE = 0.75;
//float		BUBBLE_RISE_RATE = 20;

float		NUM_SEAWEED = 12;

//_____________________________________________________ COLOUR DEFINITIONS
float4		SEAWEED_COLOUR = float4(0.27, 0.35, 0.075, 1);
float4		FLOOR_COLOUR = float4(0.5, 0.5, 0.15, 1);
float4		OCEAN_COLOUR = float4(0.0, 0.4, 0.8, 1.0);

//_____________________________________________________ TYPES ("enums")
const int		TYPE__SEABED			= 128;
const int		TYPE__OCEANSURFACE		= 127;
const int		TYPE__OBJECT			= 126;
const int		TYPE__SEAWEED			= 125;
const int		TYPE__CORAL				= 124;
//const int		TYPE__BUBBLE			= 123;
const int		TYPE__BACKGROUND_MISS	= 0;

//_____________________________________________________ STRUCTS/TYPES

struct material {
	float4 diffuse;
	float4 specular;
	float4 ambient;
	float shininess;
};

struct Ray {
	float3 o; // origin
	float3 d; // direction
};

struct VS_QUAD {
	float4 Position : SV_POSITION; // vertex position
	float2 TextureUV : TEXCOORD0; // vertex texture coords
};

struct PS_OUTPUT {
	float4 RGBColor : SV_Target; // Pixel color
};

struct VS_OUTPUT {
	float4 Position : SV_POSITION;
	float4 Diffuse : COLOR0;
	float2 TextureUV: TEXCOORD0;
};

//_________________________________________________________________________ DECLARATIONS

// Detail level of ocean floor. LARGE controls large features, SMALL controls fine details
const float     OCEAN_FLOOR_OCTAVES_LARGE = 3;
const float		OCEAN_FLOOR_OCTAVES_SMALL = 5;
// Control height of Large details and Small details of Ocean floor
const float		OCEAN_FLOOR_SCALER_LARGE = 8;
const float		OCEAN_FLOOR_SCALER_SMALL = 0.15;
// Control XZ scale of noise
const float     NOISE_XZ_LARGE = 0.15;
const float     NOISE_XZ_SMALL = 2.0;
// Control variance of sand texture
const float		FLOOR_C_VARIATION = 0.095;		// higher = higher difference between colours
const float		FLOOR_C_XZSCALE = 30;			// higher = smaller colour patches
// Fog modification
const float4	FOG_COLOUR = float4(0.0, 0.00025, 0.0008, 1);
const float		DISTANCE_SCALE = 0.02;
// Displacement
const float		DISPLACEMENT_COEFF = 0.5;

// Matrices
float3x3		m = float3x3(0.00, 1.60, 1.20, -1.60, 0.72, -0.96, -1.20, -0.96, 1.28);
float2x2		m2 = float2x2(1.6, -1.2, 1.2, 1.6);

//_____________________________________________________ Raymarching values
const int		NUM_STEPS = 8;
const float		PI = 3.1415;
const float		EPSILON = 1e-3;

//_____________________________________________________ Water values
float			waterlevel = 60.0; // height of the water
float			wavegain = 2.0; // change to adjust the general water wave level
float			large_waveheight = 0.9; // change to adjust the "heavy" waves
float			small_waveheight = 0.7; // change to adjust the small waves

//_____________________________________________________ Misc values
float3			fogcolor = float3(0.5, 0.7, 1.1);
float3			skybottom = float3(0.6, 0.8, 1.2);
float3			skytop = float3(0.05, 0.2, 0.5);
float3			reflskycolor = float3(0.025, 0.10, 0.20);
float3			watercolor = float3(0.2, 0.25, 0.3);
float3			light = normalize(float3(0.1, 0.25, 0.9));

//_________________________________________________________________________ SHAPE FUNCTIONS

//_____________________________________________________ Repetition function
void repeatX(inout float3 coord, float spacing){
	coord.x = fmod(coord.x, spacing) - spacing * 0.5;
}

//_____________________________________________________ Rotation (around X) functon
float4x4 RotateX(float theta){
    float4x4 rotateX = {
        1.0, 0.0, 0.0, 0.0,
		0.0, cos(theta), -sin(theta), 0.0,
		0.0, sin(theta), cos(theta), 0.0,
		0.0, 0.0, 0.0, 1.0
    };
    return rotateX;
}

//_____________________________________________________ Rotation (around Y) function
float4x4 RotateY(float theta){
    float4x4 rotateY ={
        cos(theta), 0.0, sin(theta), 0.0,
		0.0, 1.0, 0.0, 0.0,
		-sin(theta), 0.0, cos(theta), 0.0,
		0.0, 0.0, 0.0, 1.0
    };
    return rotateY;
}

//_____________________________________________________ Rotation (around Z) function
float4x4 RotateZ(float theta){
    float4x4 rotateZ = {
        cos(theta), -sin(theta), 0.0, 0.0,
		sin(theta), cos(theta), 0.0, 0.0,
		0.0, 0.0, 1.0, 0.0,
		0.0, 0.0, 0.0, 1.0
    };
    return rotateZ;
}

//_____________________________________________________ Twist function

float3 Twist(float3 p, float amount){
	float c = cos(amount * p.y);
	float s = sin(amount * p.y);
	float2x2 m = float2x2(c, -s, s, c);
	float3 q = float3(mul(p.xz, m), p.y);
	return q;
}

//_____________________________________________________ Fog function
float4 Fog(in float4 rgb, in float distance){
    return lerp(rgb, FOG_COLOUR, (1 - exp(-distance * DISTANCE_SCALE)));
}
          
//_____________________________________________________ Hash function (assoc'd with noise function)
float hash(float n){
	return frac(cos(n) * 41415.92653);
}

//_____________________________________________________ 2D Noise
float noise(float2 p){
    return sin(p.x);
}

//_____________________________________________________ 2D Fractional Brownian motion
float fbm(float2 p){
	float f = 0.5000 * noise(p);
	p = mul( 2 *p, m2);
	f += 0.2500 * noise(p);
	p = mul(2 * p, m2);
	f += 0.1666 * noise(p);
	p = mul(p, m2);
	f += 0.0834 * noise(p);
	return f;
}

//_____________________________________________________ Water function. Calculate water as height of p
float water(float2 p){
	float height = waterlevel;
	float2 shift1 = 0.001 * float2(g_fTime * 160.0 * 2.0, g_fTime * 120.0 * 2.0);
	float2 shift2 = 0.001 * float2(g_fTime * 190.0 * 2.0, -g_fTime * 130.0 * 2.0);
    // larger waves
	float wave = 0.0;
	wave += sin(p.x * 0.021 + shift2.x) * 4.5;
	wave += sin(p.x * 0.0172 + p.y * 0.010 + shift2.x * 1.121) * 4.0;
	wave -= sin(p.x * 0.00104 + p.y * 0.005 + shift2.x * 0.121) * 4.0;
    // Smaller waves
	wave += sin(p.x * 0.02221 + p.y * 0.01233 + shift2.x * 3.437) * 5.0;
	wave += sin(p.x * 0.03112 + p.y * 0.01122 + shift2.x * 4.269) * 2.5;
	wave *= large_waveheight;
	wave -= fbm(p * 0.004 - shift2 * .5) * small_waveheight * 24.;
	float amp = 6. * small_waveheight;
	shift1 *= .3;
	for (int i = 0; i < 7; i++){
		wave -= abs(sin((noise(p * 0.01 + shift1) - .5) * 3.14)) * amp;
		amp *= .51;
		shift1 *= 1.841;
		p = mul(p,m2 * 0.9331);
	}
	height += wave;
	return height;
}

//_____________________________________________________ Simple Noise function
float SimpleNoise(float2 p){
	float2 f = frac(p);
	p = floor(p);
	float v = p.x + p.y * 1000.0;
	float4 r = float4(v, v + 1.0, v + 1000.0, v + 1001.0);
	r = frac(100000.0 * sin(r * .001));
	f = f * f * (3.0 - 2.0 * f);
	return 2.0 * (lerp(lerp(r.x, r.y, f.x), lerp(r.z, r.w, f.x), f.y)) - 1.0;
}

//_____________________________________________________ Terrain: Use noise function for terrain
float terrain(float2 p, int octaves){
	float h = 0.0; // height
	float w = 0.5; // octave weight
	float m = 0.4; // octave multiplier
	for (int i = 0; i < 12; i++){
		if (i < octaves){
			h += w * SimpleNoise((p * m));
		}
		else
			break;
		w *= 0.5;
		m *= 2.0;
	}
	return h;
}

//_____________________________________________________ Displacement function
float displacement(float3 sampleRay, float disp) {
	return (sin(DISPLACEMENT_COEFF * sampleRay.x) * sin(DISPLACEMENT_COEFF * sampleRay.y) * sin(DISPLACEMENT_COEFF * sampleRay.z)) * disp;
}

//_____________________________________________________ Sphere function
float ShortestDistSphere(float3 sampleRay, float radius){
	return length(sampleRay) - radius;
}

//_____________________________________________________ Cube/box function (size.xyz = dims in xyz)
float ShortestDistBox(float3 sampleRay, float3 size){
	float3 dist = abs(sampleRay) - size;
	return min(max(dist.x, max(dist.y, dist.z)), 0.0) + length(max(dist, 0));
}

//_____________________________________________________ Cylinder function
float ShortestDistCylinder(float3 sampleRay, float3 size) {
	return length(sampleRay.xz - size.xy) - size.z;
}

//_____________________________________________________ Plane function (arg2.w = height value)
float ShortestDistPlane(float3 sampleRay, float4 arg2){
    return dot(sampleRay, arg2.xyz) + arg2.w;
}

//_____________________________________________________ Torus function (size.x = radius, size.y = segment radius)
float ShortestDistTorus(float3 sampleRay, float2 size) {
	float2 q = float2(length(sampleRay.xz) - size.x, sampleRay.y);
	return length(q) - size.y;
}

//_____________________________________________________ Capsule function (size.x = radius, size.y = segment radius)
float ShortestDistCapsule(float3 sampleRay, float r, float c){
    return lerp(length(sampleRay.xz) - r, length(float3(sampleRay.x, abs(sampleRay.y) - c, sampleRay.z)) - r, step(c, abs(sampleRay.y)));
}

//_____________________________________________________ Union (addition) function
float Union(float dist1, float dist2) {
	return min(dist1, dist2);
}

//_____________________________________________________ Subtraction (difference) function
float Difference(float dist1, float dist2) {
	return max(-dist1, dist2);
}

//_____________________________________________________ Intersection function
float Intersection(float dist1, float dist2){
    return max(dist1, dist2);
}

//_____________________________________________________ Repeat in X&Z
float3 RepeatXZ(float3 sampleRay, float spacingX, float spacingZ){
	sampleRay.z = fmod(sampleRay.z, spacingZ) - spacingZ * 0.5;
	sampleRay.x = fmod(sampleRay.x, spacingX) - spacingX * 0.5;
	return sampleRay;
}

//_____________________________________________________ Scene Distance Func: mathematical definition of scene
float SceneDistanceFunc(float3 sampleRay, inout int objType){
	// ---- Coral plates ----
	// Batch 1
	float3	coralRay1 = sampleRay - float3(12, 0, -10);

	// ---- coral Twist/transform ----
	// Batch 1
	coralRay1 = Twist(mul(mul(coralRay1, RotateY(0.035)), RotateX(0)), 0.6);

	// ---- coral SD Functions ----
	// Batch 1
	float coral1 = ShortestDistTorus(coralRay1, 4);

	// ---- Seaweed rays ----
	// Batch 1
	float3	seaWeedRay1 = sampleRay - float3(-1,	0,	-10);
	float3	seaWeedRay2 = sampleRay - float3(-5,	0,	-11);
	float3	seaWeedRay3 = sampleRay - float3(-3.6,	0,	-18.5);
	// Batch 2
	float3	seaWeedRay4 = sampleRay - float3(7,		0,	-47);
	float3	seaWeedRay5 = sampleRay - float3(5,		0,	-45);
	// Batch 3
	float3	seaWeedRay6 = sampleRay - float3(-36,	0,	-77);
	float3	seaWeedRay7 = sampleRay - float3(-38,	0,	-75);
	float3	seaWeedRay8 = sampleRay - float3(-30,	0,	-77);
	float3	seaWeedRay9 = sampleRay - float3(-32,	0,	-77);
	float3	seaWeedRay10 = sampleRay - float3(-34,	0,	-75);
	float3	seaWeedRay11 = sampleRay - float3(-36,	0,	-73);
	float3	seaWeedRay12 = sampleRay - float3(-38,	0,	-71);

	// ---- Seaweed Twist/transform ----
	// Batch 1
	seaWeedRay1 = Twist(mul(mul(seaWeedRay1, RotateY(0.35 + (0.15 + sin(g_fTime) * (1.3 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.1));
	seaWeedRay2 = Twist(mul(mul(seaWeedRay2, RotateY(0.30 + (0.45 + g_fTime * (1.05 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.9));
	seaWeedRay3 = Twist(mul(mul(seaWeedRay3, RotateY(0.55 + (1.95 + sin(g_fTime) * (0.3 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.2));
	// Batch 2
	seaWeedRay4 = Twist(mul(mul(seaWeedRay4, RotateY(0.40 + (1.35 + sin(g_fTime) * (0.9 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.7));
	seaWeedRay5 = Twist(mul(mul(seaWeedRay5, RotateY(0.35 + (1.55 + g_fTime * (0.75 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.2));
	// Batch 3
	seaWeedRay6 = Twist(mul(mul(seaWeedRay6, RotateY(0.30 + (1.75 + sin(g_fTime) * (0.8 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.1));
	seaWeedRay7 = Twist(mul(mul(seaWeedRay7, RotateY(0.35 + (1.95 + g_fTime * (0.7 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.5));
	seaWeedRay8 = Twist(mul(mul(seaWeedRay8, RotateY(0.35 + (1.37 + sin(g_fTime) * (0.85 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.2));
	seaWeedRay9 = Twist(mul(mul(seaWeedRay9, RotateY(0.35 + (1.5 + sin(g_fTime) * (0.9 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.0));
	seaWeedRay10 = Twist(mul(mul(seaWeedRay10, RotateY(0.35 + (1.05 + g_fTime * (0.95 * SEAWEED_TWISTRATE)))), RotateX(0)), (SEAWEED_TWIST * 1.7));

	// ---- Seaweed SD Functions ----
	// Batch 1
	float seaweedstrip1 = ShortestDistBox(seaWeedRay1, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT));
	float seaweedstrip2 = ShortestDistBox(seaWeedRay2, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 5));
	float seaweedstrip3 = ShortestDistBox(seaWeedRay3, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 2));
	// Batch 2
	float seaweedstrip4 = ShortestDistBox(seaWeedRay4, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT));
	float seaweedstrip5 = ShortestDistBox(seaWeedRay5, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 15));
	// Batch 3
	float seaweedstrip6 = ShortestDistBox(seaWeedRay6, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 20));
	float seaweedstrip7 = ShortestDistBox(seaWeedRay7, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 1));
	float seaweedstrip8 = ShortestDistBox(seaWeedRay8, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 5));
	float seaweedstrip9 = ShortestDistBox(seaWeedRay9, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 8));
	float seaweedstrip10 = ShortestDistBox(seaWeedRay10, float3(SEAWEED_WIDTH, 0.03, SEAWEED_HEIGHT - 11));

	// Accumulatively union (min) the seaweed objects
	float seaweedresult = 1000000;
	float seaweednearest = 1000000;
	// Init array, accumulate iteratively
	const int seaweedobjectCount = 10;

	float seaweedobjects[] = { 
			seaweedstrip1,		seaweedstrip2,		seaweedstrip3,		seaweedstrip4,
			seaweedstrip5,		seaweedstrip6,		seaweedstrip7,		seaweedstrip8,
			seaweedstrip9,		seaweedstrip10
	};

	for (int i = 0; i < seaweedobjectCount; ++i) {
		seaweedresult = Union(seaweedresult, seaweedobjects[i]);
		seaweednearest = min(seaweednearest, seaweedobjects[i]);
	}

	// ----------------------------------------------------------------------------------------------------------------
	// Ocean floor - sand "dunes" etc
	float floor =	ShortestDistPlane(sampleRay, float4(0.0, 1, 0, 3)) + 
					(terrain((sampleRay.xz * NOISE_XZ_LARGE), OCEAN_FLOOR_OCTAVES_LARGE) * OCEAN_FLOOR_SCALER_LARGE) +
					(terrain((sampleRay.xz * NOISE_XZ_SMALL), OCEAN_FLOOR_OCTAVES_SMALL) * OCEAN_FLOOR_SCALER_SMALL);
	// ----------------------------------------------------------------------------------------------------------------
	// The "ocean" - underside of the ocean's surface
	float ocean =	ShortestDistPlane(sampleRay, float4(0.0, -1, 0, 15)) + water(sampleRay.xz);;
	// ----------------------------------------------------------------------------------------------------------------
	// DISABLED - LOOKS TERRIBLE
	// Bubbles
	//float3		bubbleRay1 = sampleRay - float3(-19, waterlevel - ((waterlevel % g_fTime) * g_fTime), -10);
	//float		bubble1 = ShortestDistSphere(bubbleRay1, 4);

	// ----------------------------------------------------------------------------------------------------------------

	const int objectCount = 4;
    float objects[] = { floor, ocean, seaweedresult, coral1 };

     // add - union stuff
    float result = 1000000;
    float nearest = 1000000;

    for (int i = 0; i < objectCount; ++i){
        result = Union(result, objects[i]);
        nearest = min(nearest, objects[i]);
    }
    if(objType != -1){
        if (nearest == coral1){
            objType = TYPE__CORAL;
        }
        else if (nearest == seaweedresult){
            objType = TYPE__SEAWEED;
        }
        else if (nearest == floor){
            objType = TYPE__SEABED;
        }
		else if (nearest == ocean) {
			objType = TYPE__OCEANSURFACE;
		}
		//else if (nearest == bubble1) {
		//	objType = TYPE__BUBBLE;
		//}
		else {
            objType = TYPE__BACKGROUND_MISS;
        }
    }
    return result;
}

//_____________________________________________________ Get Normal for lighting
float3 GetNormal(float3 p) {
    int empty = -1;
	return normalize(float3(
		(SceneDistanceFunc(float3(p.x + ERR_TOLERANCE, p.y, p.z), empty) - SceneDistanceFunc(float3(p.x - ERR_TOLERANCE, p.y, p.z), empty)),
		(SceneDistanceFunc(float3(p.x, p.y + ERR_TOLERANCE, p.z), empty) - SceneDistanceFunc(float3(p.x, p.y - ERR_TOLERANCE, p.z), empty)),
		(SceneDistanceFunc(float3(p.x, p.y, p.z + ERR_TOLERANCE), empty) - SceneDistanceFunc(float3(p.x, p.y, p.z - ERR_TOLERANCE), empty))
	));
}

//_____________________________________________________ Lighting Calculation
float4 Shading(float shininess, float3 lightDir, float3 hitNormal, float3 viewDirection) {
	// apply blinn/phong lighting
    lightDir = normalize(lightDir);
	float ndotl = dot(hitNormal, lightDir);
	float3 halfVec = normalize(viewDirection + lightDir);
	float ndoth = dot(hitNormal, halfVec);
	return lit(ndotl, ndoth, shininess);
}

//_____________________________________________________ Depth State(s)
DepthStencilState EnableDepth {
    DepthEnable = TRUE;
    DepthWriteMask = ALL;
    DepthFunc = LESS_EQUAL;
};

//_____________________________________________________ Texture Sampler(s)
SamplerState MeshTextureSampler {
    Filter = MIN_MAG_MIP_LINEAR;
    AddressU = Wrap;
    AddressV = Wrap;
};

//_____________________________________________________ Vertex Shader Output
VS_QUAD RenderSceneVS_RT(float4 vPos : POSITION) {
	VS_QUAD Output;
	Output.Position = float4(sign(vPos.xy), 0, 1);
	Output.TextureUV = sign(vPos.xy);
	return Output;
}

//_____________________________________________________ Calculate first hit
float HitDistance(float3 pos, float3 dir, float start, float end, out int objType) {
	float hit = start;
	for (int i = 0; i < MAX_STEPS; i++) {
		// Hit?
		float dist = SceneDistanceFunc(pos + hit * dir, objType);
		if (dist < ERR_TOLERANCE) return hit;
		// increment depth
		hit += dist;
		// exceeded limit
		if (hit > end) {
			return end;
		}
	}
	return end;
}

//_____________________________________________________ Main Raymarching function
float4 RayMarch(VS_QUAD input){
	float2 xy = 0.02 * input.TextureUV * float2(g_windowWidth, g_windowHeight);
	float3 pos = float3(xy, 1);

	Ray eye;
	// Eye position (world)
	eye.o = eyePosition;
	// Normalize
	eye.d = mul(normalize(pos - eye.o.xyz), transpose(g_mWorld));
	// Find shortest distance
    int objType = 0;
	float shortestDist = HitDistance(eye.o, eye.d, MIN_DISTANCE, MAX_DISTANCE, objType);
	float3 hitpoint = eye.o + shortestDist * eye.d;
    // Default colour (background, or "miss")
    float4 colour = bgColour;
	material mat;
    // Material properties (set/init default)
	mat.diffuse =   float4(0.0, 0.0, 0.0, 1.0);
	mat.specular =  float4(0.0, 0.0, 0.0, 1.0);
	mat.ambient =   float4(0.0, 0.0, 0.0, 0.0);
	mat.shininess = 0;

	// Base material properties on the type of scene object
    if (objType == TYPE__SEABED){
        // Is the object the sea bed?
		mat.diffuse = FLOOR_COLOUR + SimpleNoise(hitpoint.xz * FLOOR_C_XZSCALE) * FLOOR_C_VARIATION;
		mat.specular =  float4(0.0, 0.0, 0.0, 1.0);
        mat.ambient =   float4(0.0, 0.0, 0.0, 0.0);
        mat.shininess = 300;
    }
    else if (objType == TYPE__OCEANSURFACE){
        // Is the object the ocean surface?
		mat.diffuse = OCEAN_COLOUR;
        mat.specular =  float4(0.5, 0.5, 0.5, 1.0);
        mat.ambient =   float4(0.0, 0.3, 0.6, 0.0);
        mat.shininess = 120;
    }
    else if (objType == TYPE__SEAWEED){
        // Is the object seaweed?
		mat.diffuse = SEAWEED_COLOUR + SimpleNoise(hitpoint.xy * FLOOR_C_XZSCALE) * (FLOOR_C_VARIATION * 0.5);
		mat.specular =  float4(0.5, 0.5, 0.5, 1.0);
        mat.ambient =   float4(0.0, 0.0, 0.0, 0.0);
        mat.shininess = 200;
    }
	else if (objType == TYPE__CORAL) {
		// Is the object of type "Coral"?
		mat.diffuse =	float4(0.7 + terrain(hitpoint.xz, 30), 0.0, 0.0, 1.0);
		mat.specular =	float4(0.5, 0.5, 0.5, 1.0);
		mat.ambient =	float4(0.0, 0.0, 0.0, 0.0);
		mat.shininess = 150;
	}
	//else if (objType == TYPE__BUBBLE) {
	//	// Is the object of type "Coral"?
	//	mat.diffuse =	float4(1, 1, 1, 1.0);
	//	mat.specular =	float4(1.0, 1.0, 1.0, 1.0);
	//	mat.ambient =	float4(0.8, 0.8, 0.8, 0.8);
	//	mat.shininess = 250;
	//}
	else if (objType == TYPE__OBJECT){
        // Is the object of type "object"?
        mat.diffuse =   float4(0.0, 1.0, 0.0, 1.0);
        mat.specular =  float4(0.5, 0.5, 0.5, 1.0);
        mat.ambient =   float4(0.0, 0.0, 0.0, 0.0);
        mat.shininess = 250;
    }

    //
	if (shortestDist <= (MAX_DISTANCE - ERR_TOLERANCE)) {
        // Apply lighting tot he hit point (include material properties)
		float4 lighting = Shading(mat.shininess, normalize(lightPos - hitpoint), GetNormal(hitpoint), normalize(eyePosition - hitpoint));
		colour = mat.ambient + mat.diffuse * lighting.y;
		colour += mat.specular * lighting.z;
    }
    // Apply fog to the pixel
    colour = Fog(colour, shortestDist);
	colour.a = 1;
	return colour;
}

//_____________________________________________________ Render the quad
PS_OUTPUT RenderQuad(VS_QUAD In){
	PS_OUTPUT Out;
	Out.RGBColor = RayMarch(In);
	return Out;
}

//_____________________________________________________ Techniques
technique11 Tech01{
    pass P0{
		SetVertexShader(CompileShader(vs_5_0, RenderSceneVS_RT()));
		SetGeometryShader(NULL);
		SetPixelShader(CompileShader(ps_5_0, RenderQuad()));
		SetDepthStencilState(EnableDepth, 0);
	}
}

technique11 Tech02{
    pass P0{
        SetVertexShader(CompileShader(vs_5_0, RenderSceneVS_RT()));
        SetGeometryShader(NULL);
        SetPixelShader(CompileShader(ps_5_0, RenderQuad()));
        SetDepthStencilState(EnableDepth, 0);
    }
}

technique11 Tech03{
    pass P0{          
        SetVertexShader(CompileShader(vs_5_0, RenderSceneVS_RT()));
        SetGeometryShader(NULL);
        SetPixelShader(CompileShader(ps_5_0, RenderQuad()));
        SetDepthStencilState(EnableDepth, 0);
	}
}

technique11 Tech04{
    pass P0{          
        SetVertexShader(CompileShader(vs_5_0, RenderSceneVS_RT()));
        SetGeometryShader(NULL);
        SetPixelShader(CompileShader(ps_5_0, RenderQuad()));
        SetDepthStencilState(EnableDepth, 0);
	}
}

technique11 Tech05{
	pass P0{
        SetVertexShader(CompileShader(vs_5_0, RenderSceneVS_RT()));
        SetGeometryShader(NULL);
        SetPixelShader(CompileShader(ps_5_0, RenderQuad()));
        SetDepthStencilState(EnableDepth, 0);
	}
}
